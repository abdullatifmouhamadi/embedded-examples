/*
 * nucleo-f030_hal_bsp.h
 *
 *  Created on: 14 gen 2016
 *      Author: cnoviello
 */

#ifndef NUCLEO_HAL_BSP_H_
#define NUCLEO_HAL_BSP_H_

void Nucleo_BSP_Init() ;

#endif /* NUCLEO_F030_HAL_BSP_H_ */
