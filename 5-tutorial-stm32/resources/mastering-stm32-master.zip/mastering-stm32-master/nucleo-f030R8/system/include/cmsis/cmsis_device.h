#ifndef _CMSIS_H_
#define _CMSIS_H_

#include "stm32f0xx.h"

#endif // _CMSIS_H_
