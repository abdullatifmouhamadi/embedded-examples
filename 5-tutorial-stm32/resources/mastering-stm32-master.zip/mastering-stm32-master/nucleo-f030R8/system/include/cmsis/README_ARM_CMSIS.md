The ARM files are from the original `CMSIS-SP-00300-r4p4-00rel0.tgz`
archive, the folder:

* `CMSIS/Include`

The files are generally unchanged, except the `core_cm*.h` files which were
braced with pragmas to avoid several warnings.
