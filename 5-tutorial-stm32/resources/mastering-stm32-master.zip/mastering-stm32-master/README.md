# Example projects of the Mastering STM32 book
![](https://s3.amazonaws.com/titlepages.leanpub.com/mastering-stm32/small?1443252521)

This repository contains all examples presented in the "Mastering STM32" book, [published on the *leanpub*](https://leanpub.com/mastering-stm32) self-publishing platform.
